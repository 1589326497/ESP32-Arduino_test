
see [Wiki](https://github.com/pschatzmann/arduino-audio-tools/wiki/Examples)