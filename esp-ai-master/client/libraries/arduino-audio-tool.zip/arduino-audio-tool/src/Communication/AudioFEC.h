#pragma once
// Forward Error Corrections
#include "Communication/ReedSolomonFEC.h"
#include "Communication/HammingFEC.h"